function attachEvents() {
    const baseUrl = 'http://localhost:3030/jsonstore/tasks';

    const loadAllButton = document.getElementById('load-button');
    const addButton = document.getElementById('add-button');

    const titleInput = document.getElementById('title');


    const loadTasks = async (e) => {
        e.preventDefault();
        
        const response = await fetch(baseUrl);
        const data = await response.json();

        const todoList = document.getElementById('todo-list');
        todoList.innerHTML = '';

        for (const task of Object.values(data)) {
            const taskLiElement = createTaskLiElement(task);
            todoList.appendChild(taskLiElement);

            const removeButton = taskLiElement.querySelector('button');
            const editButton = taskLiElement.querySelectorAll('button')[1];
            
            removeButton.addEventListener('click', async (e) => {
                e.preventDefault();
                
                const response = await fetch(`${baseUrl}/${task._id}`, {
                    method: 'DELETE',
                });
                
                taskLiElement.remove();
            });
            
            editButton.addEventListener('click', async (e) => {
                e.preventDefault();
                
                const spanEl = taskLiElement.querySelector('span');
                spanEl.remove();
                
                let inputField = document.createElement('input')
                inputField.value = task.name
                taskLiElement.insertBefore(inputField, removeButton)
                
                editButton.remove();
                
                let submitButton = document.createElement('button')
                submitButton.textContent = 'Submit'
                taskLiElement.appendChild(submitButton)
                
                submitButton.addEventListener('click', async(e) => {
                    e.preventDefault()
                    
                    const response = fetch(`${baseUrl}/${task._id}`, {
                        method: 'PATCH',
                        headers: {
                            'content-type': 'application/json',
                        },
                        body: JSON.stringify({'name': inputField.value}),
                    });
                    
                    await loadTasks(e);
                });
            })
        }
    };

    loadAllButton.addEventListener('click', loadTasks);

    addButton.addEventListener('click', async (e) => {
        e.preventDefault();
        
        if (!titleInput.value) {
            return;
        }
        
        const response = await fetch(baseUrl, {
            method: 'POST',
            headers: {
                'content-type': 'application-js',
            },
            body: JSON.stringify({'name': titleInput.value}),
        });

        if (!response.ok) {
            return;
        }
        
        titleInput.value = '';
        
        await loadTasks(e);
    });


    function createTaskLiElement(task) {
        const liElement = document.createElement('li');

        const spanElement = document.createElement('span');
        spanElement.textContent = task.name;

        const removeButton = document.createElement('button');
        removeButton.textContent = 'Remove';

        const editButton = document.createElement('button');
        editButton.textContent = 'Edit';

        liElement.appendChild(spanElement);
        liElement.appendChild(removeButton);
        liElement.appendChild(editButton);

        return liElement;
    }
}

attachEvents();
